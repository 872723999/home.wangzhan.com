<?php

/**
 * @Author: Administrator
 * @Date:   2018-11-14 11:22:45
 * @Last Modified by:   Administrator
 * @Last Modified time: 2019-03-18 16:46:02
 */
namespace app\home\model;
use think\Model;
// 包表
class WzPackage extends Model
{
    protected $name = 'wz_package';
}