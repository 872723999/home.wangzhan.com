<?php

/**
 * @Author: Administrator
 * @Date:   2018-11-14 11:22:45
 * @Last Modified by:   Administrator
 * @Last Modified time: 2019-03-14 17:51:16
 */
namespace app\home\model;
use think\Model;
// 课程章节表
class WzChapter extends Model
{
    protected $name = 'wz_find_class_chapter';
}