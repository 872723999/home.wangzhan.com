<?php

/**
 * @Author: Administrator
 * @Date:   2018-11-14 11:22:45
 * @Last Modified by:   Administrator
 * @Last Modified time: 2019-03-20 00:15:55
 */
namespace app\home\model;
use think\Model;
// 文章表
class WzArticle extends Model
{
    protected $name = 'wz_article';
}