<?php

/**
 * @Author: Administrator
 * @Date:   2018-11-14 11:22:45
 * @Last Modified by:   Administrator
 * @Last Modified time: 2019-03-14 13:49:54
 */
namespace app\home\model;
use think\Model;
// 部分表
class WzPart extends Model
{
    protected $name = 'wz_find_class_part';
}